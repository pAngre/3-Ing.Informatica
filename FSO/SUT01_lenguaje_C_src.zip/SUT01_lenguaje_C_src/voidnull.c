/*
 * Fundamentos de Sistemas Operativos
 * (c) ETSInf, DISCA Universitat Politecnica de Valencia
 * Creative Commons.
 *
 * Ejemplos para probar el lenguaje C
 */
#include <stdio.h>
#include <stdlib.h>

int main() {
  void *v; // generic pointer
  int i[10];
  int a;
  int size;

  i[0] = 1245;
  v = i;
  a = *(int*)v; // casting should be done
  printf("a = %d \n", a);
  
  printf("Malloc size ? ");
  scanf("%d", &size);
  v = malloc(size); // big memory allocation
  if (v == NULL) return(1); // checkig error
}

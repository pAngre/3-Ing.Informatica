/*
 * Fundamentos de Sistemas Operativos
 * (c) ETSInf, DISCA Universitat Politecnica de Valencia
 * Creative Commons.
 *
 * Ejemplos para probar el lenguaje C
 */
#include <stdio.h>
#include <string.h>
#define NUMBOXES 3

typedef struct {
  char part[20]; // part type
  int quantity; // part number
  float unit_price; // part price
  char available; // there are part units
} parts_record;

int main() {
  parts_record boxes[NUMBOXES];
  int record=0;
  int i;

  /* Read data from the keyboard */
  do {
    /* Read the part name */
    printf("Part name => ");
    scanf("%s", boxes[record].part);
    /* Read the number of parts */
    printf(" Number of parts => ");
    scanf("%d", &boxes[record].quantity);
    /* Read the price of each part */
    printf(" Price of each part => ");
    scanf("%f", &boxes[record].unit_price);
    /* Indicate the record has data (V) */
    boxes[record].available = 'V';
    record ++;
  } while (record < NUMBOXES);
  
  /* Print the information */
  for (record = 0; record < NUMBOXES; record++) {
    if (boxes[record].available == 'V') {
      printf ("Box %d contains:\n", record + 1);
      printf ("Part => %s\n", boxes[record].part);
      printf ("Quantity => %d\n", boxes[record].quantity);
      printf ("Price => %f euros\n", boxes[record].unit_price);
    }
  } /* end for */
} /* end main */
 
  

/*
 * Fundamentos de Sistemas Operativos
 * (c) ETSInf, DISCA Universitat Politecnica de Valencia
 * Creative Commons.
 *
 * Ejemplos para probar el lenguaje C
 */
#include <stdio.h>

int main() {
  int number;
  int square;

  printf("Please, write a number: ");
  scanf("%d", &number);
  square = number * number;
  printf("The square of %d is %d\n", number, square);
  return(0);
}

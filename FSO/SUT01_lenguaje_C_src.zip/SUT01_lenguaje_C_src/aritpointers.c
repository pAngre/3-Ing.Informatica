/*
 * Fundamentos de Sistemas Operativos
 * (c) ETSInf, DISCA Universitat Politecnica de Valencia
 * Creative Commons.
 *
 * Ejemplos para probar el lenguaje C
 */
#include <stdio.h>

int main() {
  int Data[5] = {1,2,3,4,5};
  int *p;
  int i;
  int b;
  
  p = Data + 2; // p points to the 3rd element at address 508
  p = Data; // p points to Data (address 500)
 
  for (i = 0; i < 5; i++) {
    printf("Data[%u]=%u \n", i, Data[i]);
    printf("Data[%u]=%u \n", i, *p++);
  }
}
 

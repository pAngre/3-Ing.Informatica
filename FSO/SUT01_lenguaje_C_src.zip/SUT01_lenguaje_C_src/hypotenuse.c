/*
 * Fundamentos de Sistemas Operativos
 * (c) ETSInf, DISCA Universitat Politecnica de Valencia
 * Creative Commons.
 *
 * Ejemplos para probar el lenguaje C
 */
#include <stdio.h>
#include <math.h>

void hypotenuse(float a, float b, float *h) {
  *h = sqrt(pow(a,2) + pow(b, 2));
}

void read_catheti (float *a, float *b) {
  printf("Please enter catheti values a and b :\n");
  scanf("%f %f", a, b);
}

int main() {
  float a, b, h;

  read_catheti (&a, &b);
  hypotenuse(a, b, &h);
  printf("The hypotenuse value is %f\n", h);
}

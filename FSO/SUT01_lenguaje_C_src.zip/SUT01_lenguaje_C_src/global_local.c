/*
 * Fundamentos de Sistemas Operativos
 * (c) ETSInf, DISCA Universitat Politecnica de Valencia
 * Creative Commons.
 *
 * Ejemplos para probar el lenguaje C
 */
#include <stdio.h>

void funcion1(void);

int a = 10; // global variable

int main() {
  int b = 2; // local variable
 
  funcion1();
  a++;
  a++;
  printf("a= %d, b= %d\n", a, b);
  a++;
  funcion1();
}

void funcion1(void) {
  static int c = 4; // static var
  printf("a= %d, c= %d\n", a, c);
  c++;
}

/*
 * Fundamentos de Sistemas Operativos
 * (c) ETSInf, DISCA Universitat Politecnica de Valencia
 * Creative Commons.
 *
 * Ejemplos para probar el lenguaje C
 */
#include <stdio.h>
#define STRING_SIZE 80

int main() {
  char string[STRING_SIZE];

  printf(" Enter a string: ");
  scanf("%[^\n]s", string); // & is not needed
  printf(" The string is: %s \n", string);
}

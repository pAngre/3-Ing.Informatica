/*
 * Fundamentos de Sistemas Operativos
 * (c) ETSInf, DISCA Universitat Politecnica de Valencia
 * Creative Commons.
 *
 * Ejemplos para probar el lenguaje C
 */
#include <stdio.h>
#include <stdlib.h>

int main (int argc, char *argv[]) {
  int sum1,sum2;

  if (argc == 3) {
    sum1 = atoi(argv[1]);
    sum2 = atoi(argv[2]);
    printf("Add = %d\n", sum1 + sum2);
  } else {
    printf("Command use: %s arg1 arg2\n", argv[0]);
  }
}
 

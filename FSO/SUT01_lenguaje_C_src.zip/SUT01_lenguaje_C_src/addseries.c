/*
 * Fundamentos de Sistemas Operativos
 * (c) ETSInf, DISCA Universitat Politecnica de Valencia
 * Creative Commons.
 *
 * Ejemplos para probar el lenguaje C
 */
#include <stdio.h>

int main() {
  int N;
  int add = 0; /* Read N */

  printf("N: ");
  scanf("%d", &N);
  while (N > 0) {
    add = add + N;
    N = N - 1; /* same as N-- */
  }
  printf("1 + 2 +...+ N = %d \n", add);
  return(0);
}

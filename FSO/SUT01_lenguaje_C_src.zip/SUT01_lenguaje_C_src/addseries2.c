/*
 * Fundamentos de Sistemas Operativos
 * (c) ETSInf, DISCA Universitat Politecnica de Valencia
 * Creative Commons.
 *
 * Ejemplos para probar el lenguaje C
 */
#include <stdio.h>

int main() {
  int N, add, j;

  do {
    /* Read N */
    printf("Introduce N: ");
    scanf("%d", &N);
    add = 0;
    for (j = 0; j <= N; j++) /*nested loop*/
      add = add + j;
    printf("1 + 2 + ... + N = %d\n", add);
  } while (N > 0);/* loop end */
}
